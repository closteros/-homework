/*
SQLyog Job Agent v12.3.1 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.49 : Database - zhihu
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`zhihu` /*!40100 DEFAULT CHARACTER SET gbk */;

USE `zhihu`;

/*Table structure for table `admins` */

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=gbk;

/*Data for the table `admins` */

insert  into `admins` values 
(1,'root1','123'),
(2,'root2','123'),
(3,'root3','123'),
(4,'',''),
(5,'root11','123123'),
(6,'asdasd','asdasd'),
(7,'123123','123123'),
(8,'123123','123123'),
(9,'123','123');

/*Table structure for table `articles` */

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `content` text,
  `likes` bigint(20) DEFAULT NULL,
  `mark` bigint(20) DEFAULT NULL,
  `thanks` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=gbk;

/*Data for the table `articles` */

insert  into `articles` values 
(1,1,2,'消费者报告：红米手机被爆自燃官方称“非质量问题�\�','近日，据澎湃新闻报道，有用户反应，在其为父亲购买、已经使�\�3个多月的Redmi Note7Pro手机在未充电、正播放视频的情况下发生“自燃”，导致手机和被子烧毁，他父亲的手指也因此被烫伤。该用户质疑这款手机存在质量问题�\�\r\n\r\n据小米售后客服的说法，这款手机自燃是在外部原因下起火燃烧，并非质量问题。但小米方面目前并未出具详细的鉴定报告，无法打消该用户的顾虑和怀疑。截至发稿，小米公司也并未回复界面新闻的置评请求�\�\r\n\r\n红米Note 7Pro于今�\�3月份上市，售�\�1399元。官方网站信息显示，这款手机配有4000mAh电量电池，采用骁�\�675处理器，18个月质保期�\�\r\n\r\n实际上，这不是小米手机第一次被曝自燃。不久前，一名印度用户表示其购买的红米Note 7S手机在未充电情况下自燃。去年，还有用户称在网上购买了一部价�\�1299元的小米max1代手机，该手机在充电时发生疑似自燃情况，不仅手机完全损坏，还熏黑了床头柜�\�\r\n\r\n目前尚不知晓发生自燃事件是否是由于产品质量导致。据业内人士透露，每一款智能手机在出厂前都会经过多项安全测试，但如果电池内部装配线等结构组件在组装时出错，会引发电池故障，当遭遇外部不利因素时，可能会发生自燃或爆炸�\�\r\n\r\n而除了质量问题外，还有多种因素都可能引发智能手机自燃。比如阳光暴晒、过度充电、物理损坏、电池涉水等都有可能引发手机自燃或爆炸�\�\r\n\r\n近年来，除了小米手机外，三星S10、iPhone XS Max等手机也发生几起自燃现象。但这些事件涉及的相关手机产品并未发生规模性的自燃或爆炸事件，因此未形成广泛关注�\�\r\n\r\n上一次手机自燃引发轩然大波可以追溯至2016年的三星Galaxy Note7产品�\�\r\n\r\n2016年，三星Note 7手机发布后一个多月，在全球范围内发生三十多起因电池缺陷造成的爆炸和起火事故。经过调查，三星表示爆炸起因是三星SDI制造的电池本身存在问题，导致电池电芯遇热时会突发性出现膨胀、短路情形�\�\r\n\r\n当时有分析认为，三星是为了赶在竞争对手产品，尤其是苹果iPhone 7上市之前，加快Note 7的推出周期，导致产品质量出现问题。此外，Note 7在产品设计上的革新，如首次采�\�12层PCB板，不可拆卸型电池等特点也导致出现安全事故的风险上升�\�\r\n\r\n事件发生后，三星在全球范围召回Note 7，并叫停了Note 7的销售和置换。Note 7设备售价882美元，据分析师估算，该事件给三星带来最�\�170亿美元的损失，几乎意味着高端手机Galaxy  Note的终结。而这次事件还引发了品牌声誉受损、消费者信心丧失等短期难以恢复的负面影响�\�\r\n\r\n产品是手机厂商的核心竞争力，而产品质量安全更是重中之重。目前来看，红米Note7自燃是个别案例，还未成为普遍情况，但从对用户负责的角度讲，小米应当出具详细的鉴定报告，以打消消费者疑虑�\�\r\n\r\n另一方面，在各大手机厂商竞争激烈的当下，对小米公司来说，重视产品质量和用户口碑也是在竞争中生存的必然要求�\�',14,0,1),
(3,7,2,'贵州织金煤矿事故�\�7人遇�\�','多知一点：矿难之后如何自救�\�\r\n\r\n(1)当现场人员被涌水围困无法退出时，应迅速进入预先筑好的避难硐室中避灾，或选择合适地点快速建筑临时避难硐室避灾。如系老空透水，则须在避难硐室处建临时挡墙或吊挂风帘，防止被涌出的有害气体伤害。进入避难硐室前，应在硐室外留设明显标志�\�\r\n\r\n(2)在避灾期间，遇险矿工要有良好的精神心理状态，情绪安定、自信乐观、意志坚强。要坚信上级领导一定会组织人员快速营救；坚信在班组长和有经验老工人的带领下，一定能够克服各种困难，共渡难关，安全脱险。要做好长时间避灾的准备，除轮流担任岗哨观察水情的人员外，其余人员均应静卧，以减少体力和空气消耗�\�\r\n\r\n(3)避灾时，应用敲击的方法有规律、间断地发出呼救信号，向营救人员指示躲避处的位置�\�\r\n\r\n(4)被困期间断绝食物后，即使在饥饿难忍的情况下，也应努力克制自己，决不嚼食杂物充饥。需要饮用井下水时，应选择适宜的水源，并用纱布或衣服过滤�\�\r\n\r\n(5)长时间被困在井下，发觉救护人员来营救时，避灾人员不可过度兴奋和慌乱。得救后，不可吃硬质和过量的食物，要避开强烈的光线，以防发生意外�\�',5,0,1),
(4,9,3,'柯洁拿了个斗地主冠军，自己发微博：不务正业嗷�\�','我记着是想要去日本留学。蒋劲夫退出娱乐圈的消息传得沸沸扬扬，蒋劲夫已经很少出现在大家的视野了，他在微博上晒女友、晒纹身、晒发福照，完全是放飞自我的样子，就连新剧《回明之杨凌传》上映，也没见他宣传，很多网友觉得，这完全是一副要退圈的模样�\�',8,0,1),
(6,8,5,'柯洁获斗地主冠军是什么梗？柯洁不是围棋冠军吗？棋牌不分家�\�','据腾讯棋牌消息，围棋世界冠军柯洁成功拿下腾讯斗地主锦标赛全民星赛冠军！柯洁虽然以第三名获得决赛席位，但在决赛中以稳健的牌局策略一路过关斩将，9局结束�\�8300分的成绩获得冠军�\�\r\n\r\n柯洁在拿到斗地主冠军后接受采访表示很激动，这是第一次拿到斗地主的冠军。对自己的冠军成绩很满意，只是对前两局的牌面不太满意，整体发挥没有什么致命失误。斗地主是自己接触过最多的牌类游戏�\�\r\n\r\n柯洁1997年出生于浙江，是中国围棋当之无愧的第一人，是最年轻七冠王，也是AlphaGo最后要击败的对手�\�\r\n\r\n2015�\�1月第二届百灵杯决赛，不满18岁的柯洁3�\�2胜邱峻，为自己赢下第一个世界冠军。之后的几年时光，柯洁摘得三次三星杯冠军，一次梦百合冠军，一次新奥杯冠军。追平刘昌赫在世界大赛的夺冠纪录�\�\r\n\r\n2018�\�1月，柯洁在百灵杯决赛中零封申真谞，夺得个人第七个世界冠军。柯洁成为继古力（八冠）之后，中国的第二个拿到七座世界冠军奖杯的棋手。同时，他以21�\�168天的年龄打破了“最年幼七冠王”纪录，比原先的纪录保持者李昌镐�\�\r\n\r\n22岁，于你我不过是面临毕业及身份转换。可于柯洁，已是在世界围棋巅峰处厮杀多年，并以人类的名义与不可战胜的对手生死较量�\�\r\n\r\n我们看过太多次柯洁这个名字与冠军、与第一联系在一起，我们早已在心底默认他就是王者，我们也已经太习惯看他展示给世界的胜利�\�',2,0,1),
(8,5,2,'现在我想�\�','现在我想�\�',2,0,1),
(9,4,2,'今天的天气十分的�\�','今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好今天的天气十分的好',0,0,1),
(13,2,2,'12312312312','123123123123123',0,0,1),
(14,7,2,'123123','123123',0,0,1),
(16,0,15,'1231231','2123123123',0,0,1),
(17,0,15,'你是�\�','我是陈汉�\�',0,0,1),
(18,0,15,'123','123',0,0,1),
(19,0,15,'123','123',0,0,0);

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `content` text,
  `parent_id` bigint(20) DEFAULT NULL,
  `like` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=gbk;

/*Data for the table `comments` */

insert  into `comments` values 
(1,1,1,'不错',0,NULL),
(2,1,2,'写的不错!',0,NULL);

/*Table structure for table `focus_on` */

DROP TABLE IF EXISTS `focus_on`;

CREATE TABLE `focus_on` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `target_id` bigint(20) DEFAULT NULL,
  `target_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=gbk;

/*Data for the table `focus_on` */

insert  into `focus_on` values 
(2,15,3,'user'),
(3,15,3,'question'),
(7,15,3,'user'),
(8,15,2,'question'),
(9,6,2,'user'),
(10,6,2,'question'),
(11,15,2,'user'),
(12,15,2,'user'),
(13,15,3,'user'),
(14,15,7,'question'),
(15,15,1,'user'),
(16,15,1,'question');

/*Table structure for table `hot_list` */

DROP TABLE IF EXISTS `hot_list`;

CREATE TABLE `hot_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=gbk;

/*Data for the table `hot_list` */

insert  into `hot_list` values 
(1,8),
(2,6),
(3,4),
(4,1),
(5,1),
(6,3),
(7,4),
(8,1),
(9,1),
(10,13);

/*Table structure for table `likes` */

DROP TABLE IF EXISTS `likes`;

CREATE TABLE `likes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `target_id` bigint(20) DEFAULT NULL,
  `target_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*Data for the table `likes` */

/*Table structure for table `mark` */

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `target_id` bigint(20) DEFAULT NULL,
  `target_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=gbk;

/*Data for the table `mark` */

insert  into `mark` values 
(1,15,2,'user'),
(2,15,3,'passage'),
(3,15,1,'question'),
(8,15,1,'user'),
(9,15,1,'question'),
(10,15,1,'question'),
(11,6,1,'user'),
(12,6,1,'question'),
(13,6,1,'question'),
(14,15,3,'user'),
(15,15,7,'question'),
(16,15,3,'question'),
(17,15,1,'user'),
(18,15,1,'question');

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text,
  `referrer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=gbk;

/*Data for the table `questions` */

insert  into `questions` values 
(1,'蔡徐坤为什么被�\�?',1),
(2,'你觉得蒋劲夫退出娱乐圈的原因是什�\�?',2),
(3,'12312312312312312',3),
(4,'123123123123',3),
(5,'123123123123',6),
(6,'这是个问�\�',2),
(7,'测试问题',2),
(8,'测试问题',2),
(9,'测试问题',3),
(10,'世界上最美味的食物是什�\�?',3),
(11,'太阳距离地球有多�\�?',3),
(12,'太阳距离地球有多�\�?',5),
(13,'123123123123123123123123123123123123123123123asdadasdasdasddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaaaa',5),
(14,'123123123123123123123123123123123123123123123asdadasdasdasddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaaaa',2),
(15,'sunmingsunmingsunmingsunmingsunmingsunming',2),
(16,'sunmingsunmingsunmingsunmingsunmingsunming',3),
(17,'独立文章',NULL),
(18,'123123123',5),
(19,'谁是采取坤？',2),
(20,'谁是采取坤？',5),
(21,'谁是采取坤？',13),
(22,'123123',2),
(23,'123123123',5),
(24,'123123123',14),
(25,'123123123123123',3);

/*Table structure for table `record` */

DROP TABLE IF EXISTS `record`;

CREATE TABLE `record` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `content` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=gbk;

/*Data for the table `record` */

insert  into `record` values 
(1,'李四添加文章'),
(2,'用户123登录'),
(3,'15添加文章'),
(4,'3添加问题'),
(5,'123123（管理员名）管理员登�\�'),
(6,'123123（管理员名）管理员登�\�'),
(7,'用户123登录'),
(8,'用户123登录'),
(9,'用户123登录'),
(10,'123添加收藏用户id = 15'),
(11,'123添加关注用户id = 15'),
(12,'123添加收藏问题id = 1'),
(13,'添加关注问题,id = 1'),
(14,'用户123登录');

/*Table structure for table `referrers` */

DROP TABLE IF EXISTS `referrers`;

CREATE TABLE `referrers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=gbk;

/*Data for the table `referrers` */

insert  into `referrers` values 
(1,1,1),
(2,1,2),
(3,2,1),
(4,2,3);

/*Table structure for table `system_message` */

DROP TABLE IF EXISTS `system_message`;

CREATE TABLE `system_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=gbk;

/*Data for the table `system_message` */

insert  into `system_message` values 
(3,3,'用户 zhangsan 邀请您回答问题: 世界上最美味的食物是什�\�?'),
(4,3,'用户 123123 邀请您回答问题: 太阳距离地球有多�\�?'),
(5,5,'用户 123123 邀请您回答问题: 太阳距离地球有多�\�?'),
(6,5,'用户 123 邀请您回答问题: 123123123123123123123123123123123123123123123asdadasdasdasddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaaaa'),
(7,2,'用户 123 邀请您回答问题: 123123123123123123123123123123123123123123123asdadasdasdasddddddddddddddddddddddddddddddddddddddddddddddddddaaaaaaaaaaa'),
(8,2,'用户 123 邀请您回答问题: sunmingsunmingsunmingsunmingsunmingsunming'),
(9,3,'用户 123 邀请您回答问题: sunmingsunmingsunmingsunmingsunmingsunming'),
(10,5,'用户 123 邀请您回答问题: 123123123'),
(12,5,'用户 123 邀请您回答问题: 谁是采取坤？'),
(13,13,'用户 123 邀请您回答问题: 谁是采取坤？'),
(14,2,'用户 123 邀请您回答问题: 123123'),
(15,5,'用户 123 邀请您回答问题: 123123123'),
(16,14,'用户 123 邀请您回答问题: 123123123'),
(17,3,'用户 123 邀请您回答问题: 123123123123123');

/*Table structure for table `thanks` */

DROP TABLE IF EXISTS `thanks`;

CREATE TABLE `thanks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `target_id` bigint(20) DEFAULT NULL,
  `target_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*Data for the table `thanks` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `live` varchar(50) DEFAULT '1',
  `silence` varchar(50) DEFAULT '0',
  `official` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=gbk;

/*Data for the table `users` */

insert  into `users` values 
(2,'zhangsan','123','1','1','0'),
(3,'lisi','123','1','0','0'),
(5,'zhaoliu','123','1','0','0'),
(6,'123123','123123','1','1','0'),
(12,'qqq','qqq','1','0','0'),
(13,'lihen','lihen','1','0','0'),
(14,'321321','123123','1','0','0'),
(15,'123','123','1','0','0'),
(16,'123123123','123123123','1','0','0');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
