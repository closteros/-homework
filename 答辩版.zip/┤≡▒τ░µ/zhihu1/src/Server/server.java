package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

import org.ietf.jgss.Oid;
import org.omg.CORBA.Context;
import org.omg.CORBA.ContextList;
import org.omg.CORBA.DomainManager;
import org.omg.CORBA.ExceptionList;
import org.omg.CORBA.NVList;
import org.omg.CORBA.NamedValue;
import org.omg.CORBA.Object;
import org.omg.CORBA.Policy;
import org.omg.CORBA.Request;
import org.omg.CORBA.SetOverrideType;

import com.mysql.jdbc.ResultSet;
import com.sun.corba.se.spi.activation.Server;

import zhihu.model.User;

public class server implements Server, Runnable {
	private static final int U_ADDUSER = 0;
	private static final int U_eLOGIN = 0;
	private static final int U_LOGIN = 0;
	private static final String DataConnect = null;
	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	public void run(){
		
			try {
				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
			
				int command = 0;
				if (command == U_LOGIN) {
					this.u_login();
				}
				if(command==U_eLOGIN){
					this.u_elogin();
				}
				if(command==U_ADDUSER){
					this.addUser();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
				
			
		 
		
		
	}
	
	public void yunpanServer() throws IOException, SQLException, ClassNotFoundException {
		ServerSocket ss = new ServerSocket(49999);
		System.out.println("�������ѿ�");
		while(true){
			s=ss.accept();
			Thread t=new Thread(this);
			t.start();
			}
		}
		public void u_login() throws SQLException,
		ClassNotFoundException, IOException {
			int uid = ois.readInt();
			int upw = ois.readInt();
		
			
			String sql = "select * from user where uid='"+ uid +"' and upw = '"
			+ upw + "'";
			
			ResultSet rs = null;
			if (rs.next()) {
				
			User a = new User();
				oos.writeObject(a);
				oos.flush();

			}}
		public void u_elogin() throws IOException, SQLException, ClassNotFoundException{
			String uemail=ois.readUTF();
			String sql="select * from user where uemail='"+uemail+"'";
			
			ResultSet rs = null;
			if(rs.next()){
				User a=new User();
				oos.writeObject(a);
				oos.flush();
				
			}
			
		}
		public void addUser() throws SQLException, ClassNotFoundException, IOException{
			User u=(User)ois.readObject();
			String sql ="insert into user (uid,upw,uemail) values ('"+u.getId()+"','"+
			u.getId()+"','"+u.getuEmail()+"')";
			
		}
		public static void main(String[] args) {
			new server();
		}

		@Override
		public void install() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void shutdown() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void uninstall() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Request _create_request(Context ctx, String operation,
				NVList argList, NamedValue result) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Request _create_request(Context ctx, String operation,
				NVList argList, NamedValue result, ExceptionList exclist,
				ContextList ctxlist) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Object _duplicate() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public DomainManager[] _get_domain_managers() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Object _get_interface_def() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Policy _get_policy(int policyType) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int _hash(int maximum) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean _is_a(String repositoryIdentifier) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean _is_equivalent(Object other) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean _non_existent() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void _release() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Request _request(String operation) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Object _set_policy_override(Policy[] policies,
				SetOverrideType setAdd) {
			// TODO Auto-generated method stub
			return null;
		}
}

