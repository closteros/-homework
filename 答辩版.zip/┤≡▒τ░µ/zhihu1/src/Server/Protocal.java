package Server;

public class Protocal {
	int U_LOGIN =1001;
	int U_eLOGIN=1002;
	int U_ADDUSER=1003;
}
