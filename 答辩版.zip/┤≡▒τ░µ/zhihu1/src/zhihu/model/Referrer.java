package zhihu.model;

public class Referrer {

	private int id;
	private int question_id;
	private int user_id;
	public Referrer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Referrer(int question_id, int user_id) {
		super();
		this.question_id = question_id;
		this.user_id = user_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuestion_id() {
		return question_id;
	}
	public void setQuestion_id(int question_id) {
		this.question_id = question_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	@Override
	public String toString() {
		return "Referrer [id=" + id + ", question_id=" + question_id + ", user_id=" + user_id + "]";
	}
	
	
	
}
