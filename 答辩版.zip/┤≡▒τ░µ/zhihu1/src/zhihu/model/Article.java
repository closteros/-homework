package zhihu.model;

public class Article {

	private int id;
	private String question_id;
	private String user_id;
	private String title;
	private String content;
	private String likes;
	private String mark;
	private String thanks;
	public Article() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Article(int id, String question_id, String user_id, String title, String content, String likes, String mark,
			String thanks) {
		super();
		this.id = id;
		this.question_id = question_id;
		this.user_id = user_id;
		this.title = title;
		this.content = content;
		this.likes = likes;
		this.mark = mark;
		this.thanks = thanks;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion_id() {
		return question_id;
	}
	public void setQuestion_id(String question_id) {
		this.question_id = question_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getLikes() {
		return likes;
	}
	public void setLikes(String likes) {
		this.likes = likes;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getThanks() {
		return thanks;
	}
	public void setThanks(String thanks) {
		this.thanks = thanks;
	}
	@Override
	public String toString() {
		return "Article [id=" + id + ", question_id=" + question_id + ", user_id=" + user_id + ", title=" + title
				+ ", content=" + content + ", likes=" + likes + ", mark=" + mark + ", thanks=" + thanks + "]";
	}
	
	 
}
