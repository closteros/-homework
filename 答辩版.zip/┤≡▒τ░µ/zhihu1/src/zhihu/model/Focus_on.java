package zhihu.model;

public class Focus_on {

	private int id;
	private int user_id;
	private int target_id;
	private String target_type;
	public Focus_on() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Focus_on(int user_id, int target_id, String target_type) {
		super();
		this.user_id = user_id;
		this.target_id = target_id;
		this.target_type = target_type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getTarget_id() {
		return target_id;
	}
	public void setTarget_id(int target_id) {
		this.target_id = target_id;
	}
	public String getTarget_type() {
		return target_type;
	}
	public void setTarget_type(String target_type) {
		this.target_type = target_type;
	}
	@Override
	public String toString() {
		return "Focus_on [id=" + id + ", user_id=" + user_id + ", target_id=" + target_id + ", target_type="
				+ target_type + "]";
	}
	

}
