package zhihu.model;

public class Mark {
	
	private int id;
	private int user_id;
	private int target_id;
	private String target_type;
	
	public Mark() {
		super();
	}
	
	public Mark(int user_id, int target_id, String target_type) {
		super();
		this.user_id = user_id;
		this.target_id = target_id;
		this.target_type = target_type;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getTarget_id() {
		return target_id;
	}
	public void setTarget_id(int target_id) {
		this.target_id = target_id;
	}
	public String getTarget_type() {
		return target_type;
	}
	public void setTarget_type(String target_type) {
		this.target_type = target_type;
	}
	@Override
	public String toString() {
		return "Mark [id=" + id + ", user_id=" + user_id + ", target_id=" + target_id + ", target_type="
				+ target_type + "]";
	}
}
