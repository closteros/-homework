package zhihu.model;

public class Comment {

	private int id;
	private int article_id;
	private int user_id;
	private String content;
	private int parent_id;
	private int like;
	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comment(int article_id, int user_id, String content, int parent_id, int like) {
		super();
		this.article_id = article_id;
		this.user_id = user_id;
		this.content = content;
		this.parent_id = parent_id;
		this.like = like;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getParent_id() {
		return parent_id;
	}
	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	@Override
	public String toString() {
		return "Comment [id=" + id + ", article_id=" + article_id + ", user_id=" + user_id + ", content=" + content
				+ ", parent_id=" + parent_id + ", like=" + like + "]";
	}
	
}
