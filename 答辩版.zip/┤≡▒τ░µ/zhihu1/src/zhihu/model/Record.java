package zhihu.model;

public class Record {

	private int id;
	private String content;
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Record(int id, String content) {
		super();
		this.id = id;
		this.content = content;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "Record [id=" + id + ", content=" + content + "]";
	}
}
