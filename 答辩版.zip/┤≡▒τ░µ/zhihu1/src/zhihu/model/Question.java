package zhihu.model;

public class Question {

	private int id;
	private String content;
	private int referrer_id;
	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Question(String content, int referrer_id) {
		super();
		this.content = content;
		this.referrer_id = referrer_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReferrer_id() {
		return referrer_id;
	}
	public void setReferrer_id(int referrer_id) {
		this.referrer_id = referrer_id;
	}
	@Override
	public String toString() {
		return "Question [id=" + id + ", content=" + content + ", referrer_id=" + referrer_id + "]";
	}

	
}
