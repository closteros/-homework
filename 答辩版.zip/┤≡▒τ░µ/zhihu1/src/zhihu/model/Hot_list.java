package zhihu.model;

public class Hot_list {

	private int id;
	private String article_id;
	public Hot_list() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Hot_list(int id, String article_id) {
		super();
		this.id = id;
		this.article_id = article_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getArticle_id() {
		return article_id;
	}
	public void setArticle_id(String article_id) {
		this.article_id = article_id;
	}
	@Override
	public String toString() {
		return "Hot_list [id=" + id + ", article_id=" + article_id + "]";
	}
	
}
