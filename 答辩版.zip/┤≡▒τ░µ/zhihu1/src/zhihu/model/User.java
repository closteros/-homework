package zhihu.model;

public class User {

	private int id;
	private String username;
	private String password;
	private String live;
	private String silence;
	private String official;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int id, String username, String password, String live, String silence, String official) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.live = live;
		this.silence = silence;
		this.official = official;
	}
	
	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLive() {
		return live;
	}
	public void setLive(String live) {
		this.live = live;
	}
	public String getSilence() {
		return silence;
	}
	public void setSilence(String silence) {
		this.silence = silence;
	}
	public String getOfficial() {
		return official;
	}
	public void setOfficial(String official) {
		this.official = official;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", live=" + live + ", silence="
				+ silence + ", official=" + official + "]";
	}
	public String getuEmail() {
		// TODO Auto-generated method stub
		return null;
	} 
	
}
