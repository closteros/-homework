package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import zhihu.model.Message;
import zhihu.utils.JDBCUtils;

public class MessageDao {

	/*
	 * ������Ϣ
	 */
	public int addMessage(Message msg) {
		String msgContent = msg.getContent();
		String userId = msg.getUser_id() + "";
		try {
			 
			//��ȡһ������ִ��SQL���Ķ���   QueryRunner
			QueryRunner qr = new QueryRunner();
			
			String sql = "INSERT INTO system_message VALUES(null,?,?)";
			Object[] params = {userId,msgContent};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Message> queryAll() {
		List<Message> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM system_message";
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Message>(Message.class));
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
		return list;
	}

	public int deleteMessage(String id) {
		
		try {
			//����һ��QueryRunner�����������SQL����ִ��
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "DELETE FROM system_message WHERE id = ?";
			Object[] params = {id};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn, sql, params);
			//������Ĵ���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public List<Message> queryAll(String id) {
		List<Message> list = new ArrayList<Message>();
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM system_message WHERE user_id=?";
			Object[] params = {id};
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Message>(Message.class), params);
			Message msg = new Message();
			msg.setContent("[�޸�����Ϣ]");
			msg.setId(-1);
			list.add(msg);
			return list;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
}
