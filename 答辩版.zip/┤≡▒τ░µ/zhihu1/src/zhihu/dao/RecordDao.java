package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import zhihu.model.Record;
import zhihu.model.User;
import zhihu.utils.JDBCUtils;

public class RecordDao {
	
	/*
	 * ��ѯ���в���
	 */
	public List<Record> queryAllRecord() {
		List<Record> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM record";
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Record>(Record.class));
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
		return list;
	}
	
	/*
	 * ��¼����
	 */
	public void insertRecord(String content) {
		try {
			QueryRunner qr = new QueryRunner();
			String sql = "INSERT INTO record VALUES(null,?)";
			Object[] params = {content};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
