package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import zhihu.model.Admin;
import zhihu.utils.JDBCUtils;

public class AdminDao {
	
	public Admin queryAdminByUserName(Admin admin) {
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM admins WHERE adminname=?";
			Object[] params = {admin.getAdminname()};
			Connection conn = JDBCUtils.getConnection();
			Admin ad = qr.query(conn, sql, new BeanHandler<Admin>(Admin.class), params);
			//���������
			System.out.println(ad);
			return ad;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

	public int insetAdmin(Admin admin) {
		String adminname = admin.getAdminname();
		String password = admin.getPassword();
		try {
			 
			//��ȡһ������ִ��SQL���Ķ���   QueryRunner
			QueryRunner qr = new QueryRunner();
			
			String sql = "INSERT INTO admins VALUES(null,?,?)";
			Object[] params = {adminname,password};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
