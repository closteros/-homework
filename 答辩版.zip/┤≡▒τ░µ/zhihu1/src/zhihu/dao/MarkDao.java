package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import zhihu.model.Mark;
import zhihu.utils.JDBCUtils;

public class MarkDao {
	
	public List<Mark> queryByIdAndType(String userId) {
		List<Mark> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM mark WHERE user_id=? ";
			Object[] params = {userId};
			Connection conn = JDBCUtils.getConnection();
			List<Mark> cst = qr.query(conn, sql, new BeanListHandler<Mark>(Mark.class), params);
			//���������
			System.out.println(cst);
			return list;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

	public List<Mark> queryUserFromMark(String userId) {
		List<Mark> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM mark WHERE user_id=? and target_type='user' ";
			Object[] params = {userId};
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Mark>(Mark.class), params);
			//���������
			System.out.println(list);
			return list;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

	public List<Mark> queryPassageFromMark(String userId) {
		List<Mark> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM mark WHERE user_id=? and target_type='passage' ";
			Object[] params = {userId};
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Mark>(Mark.class), params);
			//���������
			System.out.println(list);
			return list;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
	public List<Mark> queryQuestionFromMark(String userId) {
		List<Mark> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM mark WHERE user_id=? and target_type='question' ";
			Object[] params = {userId};
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Mark>(Mark.class), params);
			//���������
			System.out.println(list);
			return list;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}

	public int deleteByIdAndType(String id, String type) {
		try {
			//����һ��QueryRunner�����������SQL����ִ��
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "DELETE FROM mark WHERE target_id = ? and target_type=?";
			Object[] params = {id,type};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn, sql, params);
			//������Ĵ���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public int insertMarkUser(int userId, String passageId) {
		try {
			 
			//��ȡһ������ִ��SQL���Ķ���   QueryRunner
			QueryRunner qr = new QueryRunner();
			
			String sql = "INSERT INTO mark VALUES(null,?,?,?)";
			Object[] params = {userId,passageId,"user"};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public int insertMarkQuestion(int userId, String question_id) {
		try {
			QueryRunner qr = new QueryRunner();
			String sql = "INSERT INTO mark VALUES(null,?,?,?)";
			Object[] params = {userId,question_id,"question"};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public int insertMarkPassage(int userId, String passageId) {
		try {
			QueryRunner qr = new QueryRunner();
			String sql = "INSERT INTO mark VALUES(null,?,?,?)";
			Object[] params = {userId,passageId,"question"};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}