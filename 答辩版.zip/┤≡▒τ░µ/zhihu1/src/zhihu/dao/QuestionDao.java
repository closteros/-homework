package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import zhihu.model.Question;
import zhihu.utils.JDBCUtils;

public class QuestionDao {

	/*
	 * ��������
	 */
	public int addQuestion(Question question) {
		String content = question.getContent();
		int id = question.getReferrer_id();
		try {
			 
			//��ȡһ������ִ��SQL���Ķ���   QueryRunner
			QueryRunner qr = new QueryRunner();
			
			String sql = "INSERT INTO questions VALUES(null,?,?)";
			Object[] params = {content,id};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn,sql,params);// ������ɱ����ݵ����ӡ�ɾ�������²���
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public Question queryQuestionById(String string) {
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM questions WHERE id=?";
			Object[] params = {string};
			Connection conn = JDBCUtils.getConnection();
			Question cst = qr.query(conn, sql, new BeanHandler<Question>(Question.class), params);
			//���������
			System.out.println(cst);
			return cst;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
}
