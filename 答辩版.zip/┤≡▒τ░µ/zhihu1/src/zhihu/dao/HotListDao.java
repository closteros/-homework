package zhihu.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import zhihu.model.Hot_list;
import zhihu.utils.JDBCUtils;

public class HotListDao {

	/*
	 * ��ѯ�Ȱ���Ϣ
	 */
	public List<Hot_list> queryHotList(){
		List<Hot_list> list = null;
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM hot_list";
			Connection conn = JDBCUtils.getConnection();
			list = qr.query(conn, sql, new BeanListHandler<Hot_list>(Hot_list.class));
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
		return list;
	}

	public int updateHotList(Hot_list hot_list) {
		try {
			//����һ��QueryRunner�����������SQL����ִ��
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "UPDATE hot_list SET article_id=? WHERE id=?";
			Object[] params = {hot_list.getArticle_id(),hot_list.getId()};
			Connection conn = JDBCUtils.getConnection();
			int line = qr.update(conn, sql, params);
			//������Ĵ���
			System.out.println("line="+line);
			return line;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Hot_list queryHotListById(String id){
		try{
			//��ȡQueryRunner 
			QueryRunner qr = new QueryRunner();
			//ִ��SQL���
			String sql = "SELECT * FROM hot_list WHERE id=?";
			Object[] params = {id};
			Connection conn = JDBCUtils.getConnection();
			Hot_list cst = qr.query(conn, sql, new BeanHandler<Hot_list>(Hot_list.class), params);
			//���������
			System.out.println(cst);
			return cst;
		} catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
}
