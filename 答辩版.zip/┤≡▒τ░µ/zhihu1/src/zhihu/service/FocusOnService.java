package zhihu.service;

import java.util.ArrayList;
import java.util.List;

import zhihu.dao.FocusOnDao;
import zhihu.dao.MarkBean;
import zhihu.dao.MarkDao;
import zhihu.dao.PassageDao;
import zhihu.dao.QuestionDao;
import zhihu.dao.RecordDao;
import zhihu.dao.UserDao;
import zhihu.model.Article;
import zhihu.model.Mark;
import zhihu.model.Question;
import zhihu.model.User;
import zhihu.view.user.FocusOn;

public class FocusOnService {

	private FocusOnDao focusOnDao = new FocusOnDao();
	private UserDao userDao = new UserDao();
	private QuestionDao questionDao = new QuestionDao();
	private PassageDao passageDao = new PassageDao();
	private RecordDao recordDao = new RecordDao();

	/*
	 * �����û�id��ѯ
	 */
	public List<MarkBean> queryByIdAndType(String username) {
		
		String userId = userDao.getUserIdByUsername(username);
		
		List<MarkBean> listMark = new ArrayList<MarkBean>();

		List<User> userList = queryUserFromMark(userId);
		List<Question> questionList = queryQfromMark(userId);
		
		for (int j = 0; j < userList.size(); j++) {
			MarkBean mark1 = new MarkBean();
			User user = userList.get(j);
			mark1.setId(user.getId() + "");
			mark1.setContent(user.getUsername());
			mark1.setType("user");
			listMark.add(mark1);
		}
		
		for (int a = 0; a < questionList.size(); a++) {
			MarkBean mark3 = new MarkBean();
			Question q = questionList.get(a);
			mark3.setId(q.getId() + "");
			mark3.setContent(q.getContent());
			mark3.setType("question");
			listMark.add(mark3);
		}
		
		MarkBean mkfinal = new MarkBean();
		mkfinal.setId(-1+"");
		mkfinal.setContent("[�޸����ע]");
		mkfinal.setType("-");
		
		listMark.add(mkfinal);
		
		for (int i = 0; i < listMark.size(); i++) {
			System.out.println(listMark.get(i).getContent());
		}
		
		return listMark;
	}

	/*
	 * ��ѯ�ղ��û�
	 */
	public List<User> queryUserFromMark(String userId) {
		User userById = null;

		ArrayList<User> list = new ArrayList<User>();

		List<Mark> markList = focusOnDao.queryUserFromMark(userId);
		for (int i = 0; i < markList.size(); i++) {
			Mark mark = markList.get(i);
			int user_Id = mark.getTarget_id();
			userById = userDao.queryUserById(user_Id + "");
			list.add(userById);
		}

		return list;
	}
	
	/*
	 * ��ѯ�ղ�����
	 */
	public List<Question> queryQfromMark(String userId) {
		Question q = null;

		ArrayList<Question> list = new ArrayList<Question>();

		List<Mark> markList = focusOnDao.queryQuestionFromMark(userId);
		for (int i = 0; i < markList.size(); i++) {
			Mark mark = markList.get(i);
			int q_id = mark.getTarget_id();
			q = questionDao.queryQuestionById(q_id+"");
			list.add(q);
		}

		return list;
	}


	
	/*
	 * ɾ���ղ�
	 */
	public void deleteByIdAndType(String id, String type) {
		recordDao.insertRecord("ɾ���ղ�,id = " + id + ", type= " + type);
		focusOnDao.deleteByIdAndType(id,type);
	}

	public boolean insertFocusOnUser(String username, String passageId) {
		/*
		 * ����
		 * 	����id
		 *	�û�id
		 * 	�ղ�����
		 * 		user
		 */
		User user = new User();
		user.setUsername(username);
		User user_ = userDao.queryUserByUserName(user);
		int userId = user_.getId();
		
		int line = focusOnDao.insertFocusOnUser(userId,passageId);
		
		if(line>0) {
			recordDao.insertRecord( username + "���ӹ�ע�û�id = " + userId );
			return true;
		}else{
			return false;
		}
		
	}

	public boolean insertFocusOnQuestion(String username, String passageId) {
		User user = new User();
		user.setUsername(username);
		User user_ = userDao.queryUserByUserName(user);
		int userId = user_.getId();
		/*
		 * ����passageId���ҵ�QuestionId
		 */
		Article article = passageDao.queryPassageById(passageId);
		String question_id = article.getQuestion_id();

		int line = focusOnDao.insertFocusOnQuestion(userId,question_id);
		
		if(line>0) {
			recordDao.insertRecord("���ӹ�ע����,id = " + question_id );
			return true;
		}else {
			return false;
		}
		
	}

}