package zhihu.service;

import java.util.List;

import javax.swing.JOptionPane;

import zhihu.dao.PassageDao;
import zhihu.dao.RecordDao;
import zhihu.dao.UserDao;
import zhihu.model.Article;

public class PassageService {

	private PassageDao passageDao = new PassageDao();
	private UserDao userDao = new UserDao();
	private RecordDao recordDao = new RecordDao();
	
	/*
	 * �Զ���ѯ�Ȱ�
	 */
	public List<Article> queryHotPassageOrderByLikeAndMarkAndThanks() {
		return passageDao.queryHotPassageOrderByLikeAndMarkAndThanks();
	}
	
	/*
	 * ��������
	 */
	public boolean addPassage(Article article,String username) {
		String userId = userDao.getUserIdByUsername(username);
		article.setUser_id(userId);
		
		int line = passageDao.addPassage(article);
		if(line > 0) {
			recordDao.insertRecord(userId + "��������");
			return true;
		}else {
			return false;
		}
	}
	
	/*
	 * ��ѯ��һ��δ��˵�����
	 */
	public Article queryTheFirstUNPASS_passage() {
		List<Article> list = passageDao.queryAllUNPASS_pass();
		if(list==null) {
			return null;
		}else if(list.size()<=0){
			return null;
		}else {
			return list.get(0);
		}
	}
	
	/*
	 * �ı������״̬
	 */
	public boolean changeTheStatusOfPassage(Article article){
		int line = passageDao.changeTheStatusOfPassage(article);
		if(line > 0) {
			return true;
		}else {
			return false;
		}
	}
	
	/*
	 *��ѯ���е�����
	 */
	public List<Article> queryAllpass() {
		return passageDao.queryAllpass();
	}
	
	/*
	 * ɾ������δͨ����˵�����
	 */
	public boolean deleteUNPASS_pass() {
		int line = passageDao.deleteUNPASS_pass();
		if(line>0) {
			recordDao.insertRecord("ɾ������δ�������");
			return true;
		}else {
			return false;
		}
	}
	
	/*
	 * ����id��ѯ����
	 */
	public Article queryPassageById(String id) {
		return passageDao.queryPassageById(id);
	}

	public boolean updateLikeByPassageId(String passageId) {
		Article article = queryPassageById(passageId);
		String like = article.getLikes();
		Integer integer = Integer.valueOf(like);
		if(integer.equals(null)) {
			integer=0;
		}
		integer+=1;
		System.out.println(integer);
		
		Integer p_id = Integer.valueOf(passageId);
		
		//-------------------------
		
		int line = passageDao.updateLikeByPassageId(p_id, integer);
		
		//-------------------------
		
		if(line>0) {
			return true;
		}else {
			return false;
		}
	}

	public List<Article> queryPassageByUserId(String userId) {
		return passageDao.queryPassageByUserId(userId);
	}
}