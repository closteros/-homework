package zhihu.service;

import java.util.List;

import zhihu.dao.AdminDao;
import zhihu.dao.RecordDao;
import zhihu.dao.UserDao;
import zhihu.model.Admin;
import zhihu.model.User;

public class UserService {
	
	public static UserDao userDao = new UserDao();
	private RecordDao recordDao = new RecordDao();
	
	/*
	 * ��½
	 */
	public boolean login(User user) {
		 User user_ = userDao.queryUserByUserName(user);
		 //û�в�ѯ��--->��½ʧ��
		 if(user_==null) {
			 return false;
		 //��ѯ����-->У������
		 }else {
			 if(user.getPassword().equals(user_.getPassword())) {
				 recordDao.insertRecord("�û�" + user_.getUsername() + "��¼");
				 return true;
			 } else {
				 return false;
			 }
		 }
	}

	/*
	 * �����û�
	 */
	public boolean insertUser(User user) {
		int line = userDao.insertUser(user);
		if(line > 0) {
			recordDao.insertRecord("�û�" + user.getUsername() + "ע��ɹ�");
			System.out.println("�û����ӳɹ�!");
			return true;
		} else {
			System.out.println("�û�����ʧ��!");
			return false;
		}
	}
	
	/*
	 * ����id��ѯ�û���Ϣ
	 */
	public User queryUserById(String id) {
		return userDao.queryUserById(id);
	}
	

	public List<User> queryAllUser() {
		return userDao.queryAllUser();
	}
	
	public boolean updateCustomer(User user) {
		int line = userDao.updateCustomer(user);
		if(line>0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean deleteUser(String id) {
		int line = userDao.deleteUserById(id);
		if(line>0) {
			recordDao.insertRecord("�û�id =" + id + "��ɾ���ɹ�");
			return true;
		}else {
			return false;
		}
	}

	public User queryUserByUsername(String username) {
		User user = new User();
		user.setUsername(username);
		System.out.println(user.toString());
		System.out.println("û�н���dao�鵽��" + user.getId());
		User user_ = userDao.queryUserByUserName(user);
		System.out.println("�鵽��" + user_.getId());
		return user_;
	}
	
	/*
	 * ����
	 */
	
	
	
}
