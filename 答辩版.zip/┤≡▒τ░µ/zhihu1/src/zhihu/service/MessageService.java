package zhihu.service;

import java.util.List;

import zhihu.dao.MessageDao;
import zhihu.dao.UserDao;
import zhihu.model.Message;

public class MessageService {
	
	private MessageDao messageDao = new MessageDao();
	private UserDao userDao = new UserDao();
	
	/*
	 * ������Ϣ
	 */
	public boolean addMessage(Message msg) {
		int line = messageDao.addMessage(msg);
		if(line>0) {
			return true;
		}else {
			return false;
		}
	}

	public List<Message> queryAll() {
		return messageDao.queryAll();
	}

	public void deleteMessage(String id) {
		messageDao.deleteMessage(id);
	}

	public List<Message> queryAll(String username) {
		String idByUsername = userDao.getUserIdByUsername(username);
		return messageDao.queryAll(idByUsername);
	}

}
