package zhihu.service;

import java.util.List;

import zhihu.dao.HotListDao;
import zhihu.model.Hot_list;

public class HotListService {

	private HotListDao hotListDao = new HotListDao();
	
	public List<Hot_list> queryHotList(){
		return hotListDao.queryHotList();
	}

	public int updateHotList(Hot_list hot_list) {
		return hotListDao.updateHotList(hot_list);
	}
	
	public Hot_list queryHotListById(String id){
		return hotListDao.queryHotListById(id);
	}
	
}
