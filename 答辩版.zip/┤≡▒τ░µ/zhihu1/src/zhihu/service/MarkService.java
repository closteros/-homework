package zhihu.service;

import java.util.ArrayList;
import java.util.List;

import zhihu.dao.MarkBean;
import zhihu.dao.MarkDao;
import zhihu.dao.PassageDao;
import zhihu.dao.QuestionDao;
import zhihu.dao.RecordDao;
import zhihu.dao.UserDao;
import zhihu.model.Article;
import zhihu.model.Mark;
import zhihu.model.Question;
import zhihu.model.User;

public class MarkService {

	private MarkDao markDao = new MarkDao();
	private UserDao userDao = new UserDao();
	private PassageDao passageDao = new PassageDao();
	private QuestionDao questionDao = new QuestionDao();
	private RecordDao recordDao = new RecordDao();

	/*
	 * �����û�id��ѯ
	 */
	public List<MarkBean> queryByIdAndType(String username) {
		
		String userId = userDao.getUserIdByUsername(username);
		
		List<MarkBean> listMark = new ArrayList<MarkBean>();

		List<User> userList = queryUserFromMark(userId);
		List<Question> questionList = queryQfromMark(userId);
		List<Article> articleList = queryPGfromMark(userId);
		
		if(userList!=null) {
			for (int j = 0; j < userList.size(); j++) {
				MarkBean mark1 = new MarkBean();
				User user = userList.get(j);
				mark1.setId(user.getId() + "");
				mark1.setContent(user.getUsername());
				mark1.setType("user");
				listMark.add(mark1);
				System.out.println(mark1);
			}
		}
		
		if(questionList!=null) {
			for (int j = 0; j < questionList.size(); j++) {
				MarkBean mark3 = new MarkBean();
				Question q = questionList.get(j);
				mark3.setId(q.getId() + "");
				mark3.setContent(q.getContent());
				mark3.setType("question");
				listMark.add(mark3);
				System.out.println(mark3);
			}
		}
		
		if(articleList!=null) {
			for (int j = 0; j < articleList.size(); j++) {
				MarkBean mark2 = new MarkBean();
				Article article = articleList.get(j);
				mark2.setId(article.getId() + "");
				mark2.setContent(article.getTitle());
				mark2.setType("article");
				listMark.add(mark2);
				System.out.println(mark2);
			}
		}
		
		MarkBean mkfinal = new MarkBean();
		mkfinal.setId(-1+"");
		mkfinal.setContent("[�޸����ղ�]");
		mkfinal.setType("-");
		
		listMark.add(mkfinal);
		
		return listMark;
	}

	/*
	 * ��ѯ�ղ��û�
	 */
	public List<User> queryUserFromMark(String userId) {
		User userById = null;

		ArrayList<User> list = new ArrayList<User>();

		List<Mark> markList = markDao.queryUserFromMark(userId);
		for (int i = 0; i < markList.size(); i++) {
			Mark mark = markList.get(i);
			int user_Id = mark.getTarget_id();
			userById = userDao.queryUserById(user_Id + "");
			list.add(userById);
		}

		return list;
	}
	
	/*
	 * ��ѯ�ղ�����
	 */
	public List<Question> queryQfromMark(String userId) {
		Question q = null;

		ArrayList<Question> list = new ArrayList<Question>();

		List<Mark> markList = markDao.queryQuestionFromMark(userId);
		for (int i = 0; i < markList.size(); i++) {
			Mark mark = markList.get(i);
			int q_id = mark.getTarget_id();
			q= questionDao.queryQuestionById(q_id+"");
			list.add(q);
		}

		return list;
	}

	/*
	 * ��ѯ�ղ�����
	 */
	public List<Article> queryPGfromMark(String userId) {
		Article article = null;

		ArrayList<Article> list = new ArrayList<Article>();

		List<Mark> markList = markDao.queryPassageFromMark(userId);
		for (int i = 0; i < markList.size(); i++) {
			Mark mark = markList.get(i);
			int passage_Id = mark.getTarget_id();
			article = passageDao.queryPassageById(passage_Id + "");
			list.add(article);
		}
		
		return list;
	}

	
	/*
	 * ɾ���ղ�
	 */
	public void deleteByIdAndType(String id, String type) {
		recordDao.insertRecord("ɾ���ղ�id" + id +", type = " +type);
		markDao.deleteByIdAndType(id,type);
	}

	public boolean insertMarkUser(String username, String passageId) {
		/*
		 * ����
		 * 	����id
		 *	�û�id
		 * 	�ղ�����
		 * 		user
		 */
		User user = new User();
		user.setUsername(username);
		User user_ = userDao.queryUserByUserName(user);
		int userId = user_.getId();
		
		int line = markDao.insertMarkUser(userId,passageId);

		if(line>0) {
			recordDao.insertRecord(user_.getUsername() + "�����ղ��û�id = " + userId);
			return true;
		}else {
			return false;
		}
	}

	public boolean insertMarkQuestion(String username, String passageId) {
		User user = new User();
		user.setUsername(username);
		User user_ = userDao.queryUserByUserName(user);
		int userId = user_.getId();
		/*
		 * ����passageId���ҵ�QuestionId
		 */
		Article article = passageDao.queryPassageById(passageId);
		String question_id = article.getQuestion_id();

		int line = markDao.insertMarkQuestion(userId,question_id);
		
		if(line>0) {
			recordDao.insertRecord(user_.getUsername() + "�����ղ�����id = " + question_id);
			return true;
		}else {
			return false;
		}
	}

	public boolean insertMarkPassage(String username, String passageId) {
		
		User user = new User();
		user.setUsername(username);
		User user_ = userDao.queryUserByUserName(user);
		int userId = user_.getId();
		
		int line = markDao.insertMarkPassage(userId,passageId);
		
		if(line>0) {
			recordDao.insertRecord(user_.getUsername() + "�����ղ�����id = " + passageId);
			return true;
		}else {
			return false;
		}
	}

}