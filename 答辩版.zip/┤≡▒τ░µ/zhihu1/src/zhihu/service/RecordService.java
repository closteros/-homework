package zhihu.service;

import java.util.List;

import zhihu.dao.RecordDao;
import zhihu.model.Record;

public class RecordService {
	
	private RecordDao recordDao = new RecordDao();
	
	public List<Record> queryAllRecord() {
		return recordDao.queryAllRecord();
	}

}
