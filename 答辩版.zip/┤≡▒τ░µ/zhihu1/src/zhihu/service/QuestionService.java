package zhihu.service;

import java.util.ArrayList;
import java.util.List;

import zhihu.dao.QuestionDao;
import zhihu.dao.RecordDao;
import zhihu.model.Message;
import zhihu.model.Question;
import zhihu.model.User;

public class QuestionService {

	private QuestionDao questionDao = new QuestionDao();
	private MessageService messageService = new MessageService();
	private RecordDao recordDao = new RecordDao();
	
	public boolean addQuestion(String username, Question question,List<User> refferrers) {
		
		int line = 0;
		int result = 0;
		
		int userId = 0;
		
		Message message = new Message();
		message.setContent("�û� " + username + " �������ش�����: " + question.getContent());
		
		for (int i = 0; i < refferrers.size(); i++) {
			userId = refferrers.get(i).getId();
			question.setReferrer_id(userId);
			result = questionDao.addQuestion(question);
			if(result>0) {
				/*
				 * �����ɹ�-->������Ϣ��������
				 */
				message.setUser_id(userId);
				messageService.addMessage(message);
			}
			line += result;
		}
		
		if(line>0) {
			recordDao.insertRecord(userId + "��������");
			return true;
		}else {
			return false;
		}
	}
	
}