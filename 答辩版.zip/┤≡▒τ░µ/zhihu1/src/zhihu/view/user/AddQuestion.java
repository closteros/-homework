/*
 * Passage.java
 *
 * Created on __DATE__, __TIME__
 */

package zhihu.view.user;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import zhihu.model.Article;
import zhihu.model.Question;
import zhihu.model.User;
import zhihu.service.PassageService;
import zhihu.service.QuestionService;

/**
 *
 * @author  __USER__
 */
public class AddQuestion extends javax.swing.JFrame {
	
	private QuestionService questionService = new QuestionService();

	private String username;
	
	private List<User> userList = new ArrayList<User>();
	private String content;
	
	public AddQuestion() {
		initComponents();
	}
	
	public AddQuestion(String username) {
		this.username = username;
		initComponents();
	}
	
	/*
	 * �������û����ƵĹ��췽��
	 */
	public AddQuestion(String username,List<User> userList,String content) {
		this.userList = userList;
		this.content = content;
		this.username = username;
		initComponents();
		initData(userList,content);
	}
	
	/*
	 * ѡ�������û����������
	 */
	public void initData(List<User> userList,String content) {
		String user_ = "������û���: ";
		for (int i = 0; i < userList.size(); i++) {
			System.out.println(userList.get(i).getUsername());
			if(i==userList.size()-1) {
				user_ += userList.get(i).getUsername();
			}else {
				user_ += userList.get(i).getUsername()+", ";
			}
		}
		System.out.println(user_);
		jTextField2.setText(user_);
		jTextPane1.setText(content);
	}

	private void initComponents() {
		setTitle("�û��˺� "+username+"���ڵ�½");
		jPanel1 = new javax.swing.JPanel();
		jLabel2 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jTextField1 = new javax.swing.JTextField();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JButton();
		jTextField2 = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextPane1 = new javax.swing.JTextPane();
		jButton4 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel2.setFont(new java.awt.Font("΢���ź�", 0, 36));
		jLabel2.setForeground(new java.awt.Color(23, 137, 255));
		jLabel2.setText("֪��");

		jButton1.setBackground(new java.awt.Color(255, 255, 255));
		jButton1.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton1.setForeground(new java.awt.Color(23, 137, 255));
		jButton1.setText("����");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setFont(new java.awt.Font("΢���ź�", 0, 12));
		jButton2.setForeground(new java.awt.Color(23, 137, 255));
		jButton2.setText("ϵͳ֪ͨ");

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setFont(new java.awt.Font("΢���ź�", 0, 12));
		jButton3.setForeground(new java.awt.Color(23, 137, 255));
		jButton3.setText("�˳���½");

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jLabel3.setFont(new java.awt.Font("΢���ź�", 0, 20));
		jLabel3.setForeground(new java.awt.Color(102, 102, 102));
		jLabel3.setText("�����û��ش�");

		jLabel4.setFont(new java.awt.Font("΢���ź�", 0, 36));
		jLabel4.setForeground(new java.awt.Color(102, 102, 102));
		jLabel4.setText("�� д �� ��");

		jScrollPane1.setViewportView(jTextPane1);

		jButton4.setFont(new java.awt.Font("΢���ź�", 0, 24));
		jButton4.setForeground(new java.awt.Color(102, 102, 102));
		jButton4.setText("����");

		jButton5.setFont(new java.awt.Font("΢���ź�", 0, 24));
		jButton5.setForeground(new java.awt.Color(102, 102, 102));
		jButton5.setText("����");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});
		
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new UserLoginFrame().setVisible(true);
				dispose();
			}
		});
		
		jLabel3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				content = jTextPane1.getText();
				new UserListFrame(username,userList,content).setVisible(true);
				dispose();
			}
		});
		
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				System.out.println(jTextField2.getText());
				System.out.println(jTextPane1.getText());

				String content = jTextPane1.getText();

				Question ques = new Question();
				ques.setContent(content);
				boolean flag = questionService.addQuestion(username, ques,userList);
				if(flag) {
					jTextField2.setText("");
					jTextPane1.setText("");
					JOptionPane.showMessageDialog(null, "�������ӳɹ�!", "", JOptionPane.INFORMATION_MESSAGE);
					dispose();
					new Home(username).setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "��������ʧ��!", "", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				454,
																				454,
																				454)
																		.addComponent(
																				jLabel4))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				103,
																				103,
																				103)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton5,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												109,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGap(
																												613,
																												613,
																												613)
																										.addComponent(
																												jButton4,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												109,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addComponent(
																												jScrollPane1,
																												javax.swing.GroupLayout.Alignment.TRAILING,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												826,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabel3)
																														.addGap(
																																18,
																																18,
																																18)
																														.addComponent(
																																jTextField2,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																736,
																																javax.swing.GroupLayout.PREFERRED_SIZE))))))
										.addContainerGap(112, Short.MAX_VALUE)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(36, 36, 36)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jLabel3)
														.addComponent(
																jTextField2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																41,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(25, 25, 25)
										.addComponent(jLabel4)
										.addGap(18, 18, 18)
										.addComponent(
												jScrollPane1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												492,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																48,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																48,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap(22, Short.MAX_VALUE)));

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/����.png")));  

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(jLabel1)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												33, Short.MAX_VALUE)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jPanel2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				19,
																				19,
																				19)
																		.addComponent(
																				jLabel2)
																		.addGap(
																				43,
																				43,
																				43)
																		.addComponent(
																				jButton1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				578,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				57,
																				57,
																				57)
																		.addComponent(
																				jButton2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				73,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				72,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGap(127, 127, 127)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap(
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel2,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addGroup(
																								jPanel1Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.BASELINE)
																										.addComponent(
																												jButton1,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												44,
																												Short.MAX_VALUE)
																										.addComponent(
																												jButton2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												38,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addComponent(
																												jButton3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												37,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addComponent(
																								jTextField1,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								43,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addGap(
																				26,
																				26,
																				26)
																		.addComponent(
																				jPanel2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addComponent(
																jLabel1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																821,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.Alignment.TRAILING,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 839,
				Short.MAX_VALUE));

		pack();
		this.setLocationRelativeTo(null);
	} 

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		dispose();
		new Home(username).setVisible(true);
	}

	private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		dispose();
		new HotList(username).setVisible(true);
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JButton jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	//������
	private javax.swing.JTextField jTextField1;
	//����
	private javax.swing.JTextField jTextField2;
	//����
	private javax.swing.JTextPane jTextPane1;

}