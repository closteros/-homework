package zhihu.view.user;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import zhihu.model.User;
import zhihu.service.UserService;
import zhihu.view.base.BaseFrame;

public class UserAddFrame extends BaseFrame {

	private static UserService userService = new UserService();

	public UserAddFrame() {
		init();
	}

	public UserAddFrame(String title) {
		super(title);
		init();
	}
	

	private JPanel mainPanel = new JPanel();
	private JLabel l1 = new JLabel("�û��˺�:");
	private JLabel l2 = new JLabel("�û�����:");
	private JTextField t1 = new JTextField();
	private JTextField t2 = new JTextField();
	private JButton add = new JButton("�� ��");
	private JButton clear = new JButton("�� ��");
	private JButton back = new JButton("�� ��");

	@Override
	protected void setup() {
		// TODO Auto-generated method stub
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setLayout(null);
		t1.setBounds(160, 10, 340, 30);
		t1.setFont(new Font("����", Font.BOLD, 16));
		l1.setBounds(20, 10, 340, 30);
		l1.setFont(new Font("����", Font.BOLD, 18));
		t2.setBounds(160, 45, 340, 30);
		t2.setFont(new Font("����", Font.BOLD, 16));
		l2.setBounds(20, 45, 340, 30);
		l2.setFont(new Font("����", Font.BOLD, 18));

		add.setBounds(20, 315, 100, 30);
		add.setFont(new Font("����", Font.BOLD, 22));
		clear.setBounds(130, 315, 100, 30);
		clear.setFont(new Font("����", Font.BOLD, 22));
		back.setBounds(240, 315, 100, 30);
		back.setFont(new Font("����", Font.BOLD, 22));
	}

	@Override
	protected void addElement() {
		// TODO Auto-generated method stub
		add(mainPanel);
		mainPanel.add(add);
		mainPanel.add(clear);
		mainPanel.add(back);
		mainPanel.add(l1);
		mainPanel.add(t1);
		mainPanel.add(l2);
		mainPanel.add(t2);

	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub
		back.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
					java.awt.EventQueue.invokeLater(new Runnable() {
						public void run() {
							dispose();
							new UserLoginFrame().setVisible(true);
						}
					});
				} catch (Exception e) {
					System.out.println("�û������������");
				}
			}

		});

		clear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				t1.setText("");
				t2.setText("");
			}
		});

		add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				User user = new User();
				user.setUsername(t1.getText());
				user.setPassword(t2.getText());
				boolean flag = userService.insertUser(user);
				if (flag) {
					t1.setText("");
					t2.setText("");

					try {
						org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
						java.awt.EventQueue.invokeLater(new Runnable() {
							public void run() {
								JOptionPane.showMessageDialog(null, "�û����ӳɹ�!", "", JOptionPane.INFORMATION_MESSAGE);
								dispose();
								new UserLoginFrame().setVisible(true);
							}
						});
					} catch (Exception e) {
						System.out.println("�û������������");
					}
				} else {
					t1.setText("");
					JOptionPane.showMessageDialog(null, "�û�����ʧ��!�û��Ѵ���!", "", JOptionPane.INFORMATION_MESSAGE);
				}

			}
		});
	}

	@Override
	protected void setFrameSelf() {
		// TODO Auto-generated method stub
		setBounds(400, 280, 600, 470);
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("�����û�");
	}

}
