/*
 * TuiJian.java
 *
 * Created on __DATE__, __TIME__
 */

package zhihu.view.user;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import zhihu.model.Article;
import zhihu.model.Hot_list;
import zhihu.model.User;
import zhihu.service.HotListService;
import zhihu.service.PassageService;
import zhihu.service.UserService;

public class HotList extends javax.swing.JFrame {

	private PassageService passageService = new PassageService();
	private UserService userService = new UserService();
	private HotListService hotListService = new HotListService();

	private static final long serialVersionUID = 1L;
	private String username;
	
	public static void main(String[] args) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new HotList().setVisible(true);
			}
		});
	}
	
	/*
	 * ��ʼ����������
	 */
	public void init() {
		String id1 = hotListService.queryHotListById(1+"").getArticle_id();
		String id2 = hotListService.queryHotListById(2+"").getArticle_id();
		String id3 = hotListService.queryHotListById(3+"").getArticle_id();
		String id4 = hotListService.queryHotListById(4+"").getArticle_id();
		
		Article a1 = passageService.queryPassageById(id1);
		Article a2 = passageService.queryPassageById(id2);
		Article a3 = passageService.queryPassageById(id3);
		Article a4 = passageService.queryPassageById(id4);
		
		User u1 = userService.queryUserById(a1.getUser_id());
		User u2 = userService.queryUserById(a2.getUser_id());
		User u3 = userService.queryUserById(a3.getUser_id());
		User u4 = userService.queryUserById(a4.getUser_id());
		
		/*
		 * ��һ��
		 */
		jLabel8.setText("����-"+u1.getUsername());
		jLabel15.setText("����: "+a1.getTitle());
		jLabel21.setText("����: "+a1.getContent());
		jLabel22.setText("������: "+a1.getLikes());
		
		/*
		 * �ڶ���
		 */
		jLabel10.setText("����-"+u2.getUsername());
		jLabel13.setText("����: "+a2.getTitle());
		jLabel11.setText("����: "+a2.getContent());
		jLabel12.setText("������: "+a2.getLikes());
		
		/*
		 * ������
		 */
		jLabel14.setText("����-"+u3.getUsername());
		jLabel16.setText("����: "+a3.getTitle());
		jLabel17.setText("����: "+a3.getContent());
		jLabel18.setText("������: "+a3.getLikes());
	
		/*
		 * ������
		 */
		jLabel23.setText("����-"+u4.getUsername());
		jLabel24.setText("����: "+a4.getTitle());
		jLabel25.setText("����: "+a4.getContent());
		jLabel26.setText("������: "+a4.getLikes());
		
		/*
		 * �Ķ�1
		 */
		final String i1 = a1.getId()+"";
		jButton7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ReadPassage(username, i1).setVisible(true);
				dispose();
			}
		});
		
		/*
		 * �Ķ�2
		 */
		final String i2 = a2.getId()+"";
		jButton15.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ReadPassage(username, i2).setVisible(true);
			}
		});
		
		/*
		 * �Ķ�3
		 */
		final String i3 = a3.getId()+"";
		jButton26.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ReadPassage(username, i3).setVisible(true);
			}
		});
		
		/*
		 * �Ķ�4
		 */
		final String i4 = a4.getId()+"";
		jButton28.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ReadPassage(username, i4).setVisible(true);
			}
		});
	}
	
	public HotList() {
		initComponents();
		init();
	}
	
	public HotList(String username) {
		this.username = username;
		initComponents();
		init();
	}

	private void initComponents() {
		
		setTitle("�û��˺� "+username+"���ڵ�½");

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jTextField1 = new javax.swing.JTextField();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jButton4 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jButton7 = new javax.swing.JButton();
		jLabel8 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jLabel14 = new javax.swing.JLabel();
		jLabel16 = new javax.swing.JLabel();
		jLabel17 = new javax.swing.JLabel();
		jLabel18 = new javax.swing.JLabel();
		jButton15 = new javax.swing.JButton();
		jButton26 = new javax.swing.JButton();
		jLabel4 = new javax.swing.JLabel();
		jLabel15 = new javax.swing.JLabel();
		jLabel21 = new javax.swing.JLabel();
		jLabel22 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel23 = new javax.swing.JLabel();
		jLabel24 = new javax.swing.JLabel();
		jLabel25 = new javax.swing.JLabel();
		jLabel26 = new javax.swing.JLabel();
		jButton28 = new javax.swing.JButton();
		jPanel3 = new javax.swing.JPanel();
		jButton19 = new javax.swing.JButton();
		jButton20 = new javax.swing.JButton();
		jPanel4 = new javax.swing.JPanel();
		jButton21 = new javax.swing.JButton();
		jButton22 = new javax.swing.JButton();
		jLabel19 = new javax.swing.JLabel();
		jLabel20 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/����.png"))); // NOI18N

		jLabel2.setFont(new java.awt.Font("΢���ź�", 0, 36));
		jLabel2.setForeground(new java.awt.Color(23, 137, 255));
		jLabel2.setText("֪��");

		jButton1.setBackground(new java.awt.Color(255, 255, 255));
		jButton1.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton1.setForeground(new java.awt.Color(23, 137, 255));
		jButton1.setText("����");
		
		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setFont(new java.awt.Font("΢���ź�", 0, 12));
		jButton2.setForeground(new java.awt.Color(23, 137, 255));
		jButton2.setText("ϵͳ֪ͨ");

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setFont(new java.awt.Font("΢���ź�", 0, 12));
		jButton3.setForeground(new java.awt.Color(23, 137, 255));
		jButton3.setText("�˳���½");

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jButton4.setBackground(new java.awt.Color(255, 255, 255));
		jButton4.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton4.setForeground(new java.awt.Color(102, 102, 102));
		jButton4.setText("�Ƽ�");
		
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});
		
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new MessageFrame(username);
			}
		});
		
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new UserLoginFrame().setVisible(true);
				dispose();
			}
		});

		jButton5.setBackground(new java.awt.Color(255, 255, 255));
		jButton5.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton5.setForeground(new java.awt.Color(102, 102, 102));
		jButton5.setText("��ע");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		jButton6.setBackground(new java.awt.Color(255, 255, 255));
		jButton6.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton6.setForeground(new java.awt.Color(23, 137, 255));
		jButton6.setText("�Ȱ�");
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/һ��.png"))); // NOI18N

		jButton7.setBackground(new java.awt.Color(255, 255, 255));
		jButton7.setFont(new java.awt.Font("΢���ź�", 0, 15));
		jButton7.setForeground(new java.awt.Color(23, 137, 255));
		
		jButton7.setText("�Ķ�ȫ��1");
		jButton15.setBackground(new java.awt.Color(255, 255, 255));
		jButton15.setFont(new java.awt.Font("΢���ź�", 0, 15));
		jButton15.setForeground(new java.awt.Color(23, 137, 255));
		jButton15.setText("�Ķ�ȫ��2");
		jButton15.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton15ActionPerformed(evt);
			}
		});

		jButton26.setBackground(new java.awt.Color(255, 255, 255));
		jButton26.setFont(new java.awt.Font("΢���ź�", 0, 15));
		jButton26.setForeground(new java.awt.Color(23, 137, 255));
		jButton26.setText("�Ķ�ȫ��3");

		jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/1.png"))); // NOI18N

		jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource( "/img/2.png"))); // NOI18N

		jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource( "/img/3.png"))); // NOI18N

		jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource( "/img/4.png"))); // NOI18N

		jButton28.setBackground(new java.awt.Color(255, 255, 255));
		jButton28.setFont(new java.awt.Font("΢���ź�", 0, 15));
		jButton28.setForeground(new java.awt.Color(23, 137, 255));
		jButton28.setText("�Ķ�ȫ��4");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(22, 22, 22)
										.addComponent(
												jButton4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												76,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jButton5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												75,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jButton6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												74,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(391, Short.MAX_VALUE))
						.addComponent(jLabel3,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(32, 32, 32)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				16,
																				16,
																				16)
																		.addComponent(
																				jLabel14))
														.addComponent(jLabel10)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel5)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel13)
																						.addComponent(
																								jLabel11)
																						.addComponent(
																								jLabel12)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jButton26)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																											  )))
														.addComponent(jLabel8)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel4)
																		.addGap(
																				18,
																				18,
																				18)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel15)
																						.addComponent(
																								jLabel21)
																						.addComponent(
																								jLabel22)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton7)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										 )))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel6)
																						.addComponent(
																								jLabel7)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addGap(
																												16,
																												16,
																												16)
																										.addComponent(
																												jLabel23)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel24)
																						.addComponent(
																								jLabel25)
																						.addComponent(
																								jLabel26)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton15)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										 )
																						.addComponent(
																								jLabel16)
																						.addComponent(
																								jLabel17)
																						.addComponent(
																								jLabel18)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton28)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																												))))
										.addContainerGap(44, Short.MAX_VALUE)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGap(24, 24, 24)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																35,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																35,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton6,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																36,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel3)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				16,
																				16,
																				16)
																		.addComponent(
																				jLabel8)
																		.addGap(
																				11,
																				11,
																				11)
																		.addComponent(
																				jLabel4)
																		.addGap(
																				32,
																				32,
																				32))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel2Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				56,
																				Short.MAX_VALUE)
																		.addComponent(
																				jLabel15)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel21)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel22)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton7) )
																		.addGap(
																				9,
																				9,
																				9)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel10)
																		.addGap(
																				9,
																				9,
																				9)
																		.addComponent(
																				jLabel5))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel13)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel11)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel12)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		 ))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton26) )
										.addGap(16, 16, 16)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel14)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel6))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel16)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel17)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel18)))
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				30,
																				30,
																				30)
																		.addComponent(
																				jLabel23))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton15)
																					 )))
										.addGap(9, 9, 9)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jLabel7)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel24)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel25)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel26)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton28))
										.addGap(16, 16, 16)));

		jPanel3.setBackground(new java.awt.Color(255, 255, 255));

		jButton19.setBackground(new java.awt.Color(255, 255, 255));
		jButton19.setFont(new java.awt.Font("΢���ź�", 0, 24));
		jButton19.setForeground(new java.awt.Color(23, 137, 255));
		jButton19.setText("д����");

		jButton20.setBackground(new java.awt.Color(255, 255, 255));
		jButton20.setFont(new java.awt.Font("΢���ź�", 0, 24));
		jButton20.setForeground(new java.awt.Color(23, 137, 255));
		jButton20.setText("д����");
		jButton20.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton20ActionPerformed(evt);
			}
		});
		
		jButton19.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new AddQuestion(username).setVisible(true);
				dispose();
			}
		});

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				jPanel3Layout.createSequentialGroup().addContainerGap(65,
						Short.MAX_VALUE).addComponent(jButton20).addGap(53, 53,
						53).addComponent(jButton19).addGap(66, 66, 66)));
		jPanel3Layout
				.setVerticalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(46, 46, 46)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton19,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																68,
																Short.MAX_VALUE)
														.addComponent(
																jButton20,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																68,
																Short.MAX_VALUE))
										.addGap(60, 60, 60)));

		jPanel4.setBackground(new java.awt.Color(255, 255, 255));

		jButton21.setBackground(new java.awt.Color(255, 255, 255));
		jButton21.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton21.setForeground(new java.awt.Color(23, 137, 255));
		jButton21.setText("�ղع���");
		jButton21.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new MarkListFrame(username);
			}
		});

		jButton22.setBackground(new java.awt.Color(255, 255, 255));
		jButton22.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton22.setForeground(new java.awt.Color(23, 137, 255));
		jButton22.setText("��ע����");
		jButton22.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new FocusOnFrame(username).setVisible(true);;
			}
		});

		jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/zjl1.png"))); // NOI18N

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jLabel19,
								javax.swing.GroupLayout.Alignment.TRAILING,
								javax.swing.GroupLayout.DEFAULT_SIZE, 409,
								Short.MAX_VALUE)
						.addGroup(
								jPanel4Layout.createSequentialGroup()
										.addComponent(jLabel20)
										.addContainerGap())
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(104, 104, 104)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jButton22,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																190,
																Short.MAX_VALUE)
														.addComponent(
																jButton21,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																190,
																Short.MAX_VALUE))
										.addGap(115, 115, 115)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(66, 66, 66)
										.addComponent(jButton21)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jButton22)
										.addGap(67, 67, 67)
										.addComponent(
												jLabel20,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												331,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel19,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(jLabel1)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				67,
																				67,
																				67)
																		.addComponent(
																				jLabel2)
																		.addGap(
																				43,
																				43,
																				43)
																		.addComponent(
																				jButton1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																		.addComponent(
																				jTextField1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				578,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				57,
																				57,
																				57)
																		.addComponent(
																				jButton2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				73,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				18,
																				18,
																				18)
																		.addComponent(
																				jButton3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				72,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				18,
																				18,
																				18)
																		.addComponent(
																				jPanel2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				656,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				26,
																				26,
																				26)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								false)
																						.addComponent(
																								jPanel3,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								jPanel4,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								394,
																								Short.MAX_VALUE))))
										.addContainerGap(70, Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jLabel1,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																836,
																Short.MAX_VALUE)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel2,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								60,
																								Short.MAX_VALUE)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addContainerGap()
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton1,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																44,
																																Short.MAX_VALUE)
																														.addComponent(
																																jButton2,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																38,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addComponent(
																																jButton3,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																37,
																																javax.swing.GroupLayout.PREFERRED_SIZE)))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addContainerGap()
																										.addComponent(
																												jTextField1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												43,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jPanel3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGap(
																												31,
																												31,
																												31)
																										.addComponent(
																												jPanel4,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addComponent(
																								jPanel2,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		this.setLocationRelativeTo(null);
	} 

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		new FocusOn(username).setVisible(true);
		this.dispose();
	}

	private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {
		new AddPassage(username).setVisible(true);
		this.dispose();
	}

	private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		new HotList(username).setVisible(true);
		this.dispose();
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		new Home(username).setVisible(true);
		this.dispose();
	}

	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton20;
	private javax.swing.JButton jButton21;
	private javax.swing.JButton jButton22;
	private javax.swing.JButton jButton26;
	private javax.swing.JButton jButton28;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel19;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel21;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel23;
	private javax.swing.JLabel jLabel24;
	private javax.swing.JLabel jLabel25;
	private javax.swing.JLabel jLabel26;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JTextField jTextField1;

}