package zhihu.view.user;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import zhihu.model.User;
import zhihu.service.UserService;
import zhihu.view.admin.AdminLoginFrame;
import zhihu.view.base.BaseFrame;

public class UserLoginFrame extends BaseFrame {
	
	private static UserService userService = new UserService();
	
	private String username;

    public UserLoginFrame(){
        init();
        
        JLabel jb=new JLabel();
        jb.setBounds(0,0,mainPanel.getWidth(),mainPanel.getHeight());
        jb.setIcon(new ImageIcon("src/img/����.png"));
        mainPanel.add(jb);
    }
    
    public UserLoginFrame(String title){
        super(title);
        init();
        
       
        
    }
    
    
    
    
    private JPanel mainPanel = new JPanel();
    
    private  JLabel nameLable = new JLabel("�� �ţ�");
    private  JLabel passwordLable = new JLabel("�� �룺");
    private  JTextField text = new JTextField();
    private  JPasswordField password = new JPasswordField();
    private  JButton login = new JButton("�� ¼");
    private  JButton register = new JButton("ע ��");
    private  JButton admin = new JButton("����Ա");
    
    
    
    @Override
    protected void setup() {

    	
    	this.setLocationRelativeTo(null);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setLayout(null);
        
        nameLable.setBounds(404,524,90,30);
        nameLable.setFont(new Font("����",Font.BOLD,24));
        passwordLable.setBounds(404,574,90,30);
        passwordLable.setFont(new Font("����",Font.BOLD,24));
        text.setBounds(514,524,260,30);
        text.setFont(new Font("����",Font.BOLD,24));
        password.setBounds(514,574,260,30);
        password.setFont(new Font("����",Font.BOLD,24));
        login.setBounds(410,632,100,30);
        login.setFont(new Font("����",Font.BOLD,22)); 
        register.setBounds(540,632,100,30);
        register.setFont(new Font("����",Font.BOLD,22)); 
        admin.setBounds(670,632,100,30);
        admin.setFont(new Font("����",Font.BOLD,22));
    }

    @Override
    protected void addElement() {
        add(mainPanel);
        
        mainPanel.add(nameLable);
        mainPanel.add(passwordLable);
        mainPanel.add(text);
        mainPanel.add(password);
        mainPanel.add(login);
        mainPanel.add(register);
        mainPanel.add(admin);
    }

    @Override
    protected void addListener() {
    	
    	login.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String un = text.getText();
				char[] ch = password.getPassword();
				String pw = new String(ch);
				User user = new User(un, pw);
				username = un;
				boolean flag = userService.login(user);
				if(flag) {
					dispose();
					try {
						org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
						java.awt.EventQueue.invokeLater(new Runnable() {
							public void run() {
								new Home(username).setVisible(true);
							}
						});
					} catch (Exception e) {
					}
				} else {
					text.setText("");
					password.setText("");
					JOptionPane.showMessageDialog(null, "��½ʧ��,�û������������!", "", JOptionPane.INFORMATION_MESSAGE);
				}
			}
            
        });
        register.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
					java.awt.EventQueue.invokeLater(new Runnable() {
						public void run() {
							dispose();
							new UserAddFrame().setVisible(true);
						}
					});
				} catch (Exception e) {
					System.out.println("�û������������");
				}
			}
        });
        admin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
					java.awt.EventQueue.invokeLater(new Runnable() {
						public void run() {
							dispose();
							new AdminLoginFrame().setVisible(true);;
						}
					});
				} catch (Exception e) {
					System.out.println("�û������������");
				}
			}
        });
    }

    @Override
    protected void setFrameSelf() {
        setBounds(400,280,1300,1000);
        this.setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}