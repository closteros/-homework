package zhihu.view.admin;

import java.util.List;

import javax.swing.JOptionPane;

import zhihu.model.Article;
import zhihu.model.Hot_list;
import zhihu.model.User;
import zhihu.service.HotListService;
import zhihu.service.PassageService;
import zhihu.service.UserService;
import zhihu.view.user.UserLoginFrame;

/**
 *
 * @author __USER__
 */
public class AdminFrame extends javax.swing.JFrame {
	
	private PassageService passageService = new PassageService();
	private UserService userService = new UserService();
	private HotListService hotListService = new HotListService();
	
	private Article unpass_article;
	
	public AdminFrame() {
		initComponents();
		getUNPASS_passage();
		getHot_list();
	}
	
	/*
	 * ��ʼ������, �Ȱ�����
	 */
	public void getHot_list() { 
		
		/*
		 * �Զ���ѯ�Ȱ����ݣ� sql��䣺SELECT * FROM articles ORDER BY likes+mark*2+thanks DESC LIMIT 0,10;
		 */
		
		List<Article> list = passageService.queryHotPassageOrderByLikeAndMarkAndThanks();
		String t1 = list.get(0).getTitle();
		String t2 = list.get(1).getTitle();
		String t3 = list.get(2).getTitle();
		String t4 = list.get(3).getTitle();
		String t5 = list.get(4).getTitle();
		String t6 = list.get(5).getTitle();
		String t7 = list.get(6).getTitle();
		String t8 = list.get(7).getTitle();
		String t9 = list.get(8).getTitle();
		String t10 = list.get(9).getTitle();
		
		jTextField5.setText("01: "+t1);
		jTextField6.setText("02: "+t2);
		jTextField7.setText("03: "+t3);
		jTextField8.setText("04: "+t4);
		jTextField9.setText("05: "+t5);
		jTextField10.setText("06: "+t6);
		jTextField11.setText("07: "+t7);
		jTextField12.setText("08: "+t8);
		jTextField13.setText("09: "+t9);
		jTextField14.setText("10: "+t10);
	}
	
	/*
	 * ��ʼ������, �������Ŀ����������
	 */
	public void getUNPASS_passage() {
		unpass_article = passageService.queryTheFirstUNPASS_passage();
		
		/*
		 * ����id��ѯ�û�������, ���ұ��浽��textfiled��
		 */
		if(unpass_article==null) {
			jTextField2.setText("(��)");
			jTextField3.setText("(��)");
			jTextPane1.setText("(��)");
		}else {
			User query_user = userService.queryUserById(unpass_article.getUser_id());
	 		jTextField2.setText(query_user.getUsername());
			jTextField3.setText(unpass_article.getTitle());
			jTextPane1.setText(unpass_article.getContent());
		}
	}

	private void initComponents() {
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		jTextField1 = new javax.swing.JTextField();
		message = new javax.swing.JButton();
		home = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jLabel5 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel6 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTextPane1 = new javax.swing.JTextPane();
		jButton7clear = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton7dis = new javax.swing.JButton();
		jLabel7 = new javax.swing.JButton();
		jLabel71 = new javax.swing.JButton();
		jLabel8 = new javax.swing.JButton();
		jTextField5 = new javax.swing.JTextField();
		jTextField6 = new javax.swing.JTextField();
		jTextField7 = new javax.swing.JTextField();
		jTextField8 = new javax.swing.JTextField();
		jTextField9 = new javax.swing.JTextField();
		jTextField10 = new javax.swing.JTextField();
		jTextField11 = new javax.swing.JTextField();
		jTextField12 = new javax.swing.JTextField();
		jTextField13 = new javax.swing.JTextField();
		jTextField14 = new javax.swing.JTextField();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/����.png")));

		jLabel2.setFont(new java.awt.Font("΢���ź�", 0, 36));
		jLabel2.setForeground(new java.awt.Color(23, 137, 255));
		jLabel2.setText("֪��");

		home.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new UserLoginFrame().setVisible(true);
				dispose();
			}
		});
		
		/*
		 * ͬ�ⰴť--->���ͨ��
		 */
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				if(unpass_article==null) {
					JOptionPane.showMessageDialog(null, "����ʧ��,���������!","", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				unpass_article.setThanks(1+"");
				passageService.changeTheStatusOfPassage(unpass_article);
				JOptionPane.showMessageDialog(null, "�����ɹ�!","", JOptionPane.INFORMATION_MESSAGE);
				dispose();
				new AdminFrame().setVisible(true);
			}
		});
		
		/*
		 * ��ͬ�ⰴť--->��˲�ͨ��
		 */
		jButton7dis.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				if(unpass_article==null) {
					JOptionPane.showMessageDialog(null, "����ʧ��,���������!","", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				unpass_article.setThanks(-1+"");
				passageService.changeTheStatusOfPassage(unpass_article);
				JOptionPane.showMessageDialog(null, "�����ɹ�!","", JOptionPane.INFORMATION_MESSAGE);
				dispose();
				new AdminFrame().setVisible(true);
			}
		});
		
		jButton7clear.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				boolean flag = passageService.deleteUNPASS_pass();
				if(flag) {
					JOptionPane.showMessageDialog(null, "�����ɹ�!","", JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, "����ʧ��!�������ʧ�ܵ�����","", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		
		jLabel7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new UserListFrame();
			}
		});
		
		jLabel71.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new RecordFrame();
			}
		});
		
		jLabel8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				new HotListFrame();
			}
		});

		jButton1.setBackground(new java.awt.Color(255, 255, 255));
		jButton1.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton1.setForeground(new java.awt.Color(23, 137, 255));
		jButton1.setText("����");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
		
		message.setBackground(new java.awt.Color(255, 255, 255));
		message.setFont(new java.awt.Font("΢���ź�", 0, 12));
		message.setForeground(new java.awt.Color(23, 137, 255));
		message.setText("ϵͳ֪ͨ");

		home.setBackground(new java.awt.Color(255, 255, 255));
		home.setFont(new java.awt.Font("΢���ź�", 0, 12));
		home.setForeground(new java.awt.Color(23, 137, 255));
		home.setText("�˳���½");

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jLabel3.setFont(new java.awt.Font("΢���ź�", 0, 36));
		jLabel3.setForeground(new java.awt.Color(102, 102, 102));
		jLabel3.setText("����Ա");

		jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/һ��.png"))); // NOI18N

		jLabel4.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel4.setForeground(new java.awt.Color(102, 102, 102));
		jLabel4.setText("������");

		jLabel5.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel5.setForeground(new java.awt.Color(102, 102, 102));
		jLabel5.setText("��   ��");

		jLabel6.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel6.setForeground(new java.awt.Color(102, 102, 102));
		jLabel6.setText("��	  ��");

		jScrollPane1.setViewportView(jTextPane1);

		jButton7clear.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton7clear.setForeground(new java.awt.Color(102, 102, 102));
		jButton7clear.setText("����������ʧ�ܵ�����");
		
		jButton7.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton7.setForeground(new java.awt.Color(102, 102, 102));
		jButton7.setText("ͬ��");
		
		jButton7dis.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jButton7dis.setForeground(new java.awt.Color(102, 102, 102));
		jButton7dis.setText("��ͬ��");

		jLabel7.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel7.setForeground(new java.awt.Color(102, 102, 102));
		jLabel7.setText("�û�����ϵͳ[ɾ��&�޸�]");
		
		jLabel71.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel71.setForeground(new java.awt.Color(102, 102, 102));
		jLabel71.setText("�û�&����Ա������¼");

		jLabel8.setFont(new java.awt.Font("΢���ź�", 0, 18));
		jLabel8.setForeground(new java.awt.Color(102, 102, 102));
		jLabel8.setText("�Ȱ����");

		jTextField5.setText("");
		jTextField6.setText("");
		jTextField7.setText("");
		jTextField8.setText("");
		jTextField9.setText("");
		jTextField10.setText("");
		jTextField11.setText("");
		jTextField12.setText("");
		jTextField13.setText("");
		jTextField14.setText("");
		
		jTextField11.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField11ActionPerformed(evt);
			}
		});

		

		jTextField13.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField13ActionPerformed(evt);
			}
		});


		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(
						jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel2Layout.createSequentialGroup()
										.addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 683,
												Short.MAX_VALUE)
										.addGap(482, 482, 482))
								.addGroup(jPanel2Layout.createSequentialGroup().addGap(36, 36, 36).addComponent(jLabel3)
										.addContainerGap(1021, Short.MAX_VALUE))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addGroup(jPanel2Layout.createSequentialGroup().addGap(34, 34, 34)
														.addGroup(jPanel2Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																.addComponent(jLabel4).addComponent(jLabel5)
																.addComponent(jLabel6))
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addGroup(jPanel2Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING)
																.addComponent(jScrollPane1,
																		javax.swing.GroupLayout.DEFAULT_SIZE, 285,
																		Short.MAX_VALUE)
																.addComponent(jTextField3,
																		javax.swing.GroupLayout.DEFAULT_SIZE, 285,
																		Short.MAX_VALUE)
																.addComponent(jTextField2,
																		javax.swing.GroupLayout.DEFAULT_SIZE, 285,
																		Short.MAX_VALUE)))
												.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(jButton7clear).addComponent(jButton7dis)
														.addComponent(jButton7)))
												.addGap(55, 55, 55).addComponent(jLabel8)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
												.addGroup(jPanel2Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(jPanel2Layout.createSequentialGroup()
																.addGroup(jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(jTextField6,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				255,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(jTextField7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				255,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(jTextField8,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				255,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(jTextField9,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				255,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
																.addGap(57, 57, 57)
																.addGroup(jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel7)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						 )
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addComponent(jLabel71)
																				.addPreferredGap(
																						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						 )
																		.addGroup(jPanel2Layout.createSequentialGroup()
																				.addGap(154, 154, 154).addGroup(
																						jPanel2Layout
																								.createParallelGroup(
																										javax.swing.GroupLayout.Alignment.LEADING)
																								))))
														.addComponent(jTextField5,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jTextField10,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jTextField11,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jTextField12,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jTextField13,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jTextField14,
																javax.swing.GroupLayout.PREFERRED_SIZE, 255,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(jPanel2Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.TRAILING)
																)
																)
												.addContainerGap()));
		jPanel2Layout.setVerticalGroup(
				jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout
						.createSequentialGroup().addGroup(jPanel2Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout
										.createSequentialGroup().addGap(26, 26, 26).addComponent(jLabel3)
										.addGap(18, 18, 18)
										.addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 7,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(44, 44, 44)
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel4)
												.addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(jLabel8).addComponent(jTextField5,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel5)
												.addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(jLabel6)
												.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 316,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(jPanel2Layout.createSequentialGroup()
														.addComponent(jTextField7,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField8,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField9,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField10,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField11,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField12,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField13,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addComponent(jTextField14,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
														.addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
														.addGroup(jPanel2Layout
																.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.BASELINE)
																.addComponent(jButton7clear).addComponent(jButton7dis).addComponent(jButton7)))))
								.addGroup(jPanel2Layout.createSequentialGroup().addGap(147, 147, 147)
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel7))
										.addGroup(jPanel2Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel71))
										.addGap(18, 18, 18)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										))
								
						.addContainerGap(138, Short.MAX_VALUE)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addComponent(jLabel1)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup().addGap(74, 74, 74).addComponent(jLabel2)
										.addGap(26, 26, 26).addComponent(jButton1)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 578,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(56, 56, 56)
										.addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 73,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 72,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING).addGroup(
						javax.swing.GroupLayout.Alignment.LEADING,
						jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 43,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 37,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(message, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 44,
												Short.MAX_VALUE))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 41,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGap(18, 18, 18).addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING,
								javax.swing.GroupLayout.PREFERRED_SIZE, 821, javax.swing.GroupLayout.PREFERRED_SIZE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
		this.setLocationRelativeTo(null);
	} 

	private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	public static void main(String args[]) {
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
		} catch (Exception e) {
			e.printStackTrace();
		}

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new AdminFrame().setVisible(true);
			}
		});
	}

	private javax.swing.JButton jButton1;
	// ֪ͨ
	private javax.swing.JButton message;
	// ��ҳ
	private javax.swing.JButton home;
	private javax.swing.JButton jButton7clear;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton7dis;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JButton jLabel7;
	private javax.swing.JButton jLabel71;
	private javax.swing.JButton jLabel8;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField10;
	private javax.swing.JTextField jTextField11;
	private javax.swing.JTextField jTextField12;
	private javax.swing.JTextField jTextField13;
	private javax.swing.JTextField jTextField14;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField5;
	private javax.swing.JTextField jTextField6;
	private javax.swing.JTextField jTextField7;
	private javax.swing.JTextField jTextField8;
	private javax.swing.JTextField jTextField9;
	private javax.swing.JTextPane jTextPane1;
}